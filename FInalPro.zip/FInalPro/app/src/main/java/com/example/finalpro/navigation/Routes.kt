package com.example.finalpro.navigation

enum class Routes(val route: String) {
    Home("home"),
    Profile("profile"),  // You can add more routes as needed
    Notifications("notifications"),
    Search("search"),
    AddThreads("addThreads"),
    Splash("splash"),
    BottomNav("bottomNav"),
    Login("login"),
    Register("register")

}
