package com.example.finalpro.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.finalpro.screens.AddThreads
import com.example.finalpro.screens.BottomNav
import com.example.finalpro.screens.Splash
import com.example.finalpro.screens.Home
import com.example.finalpro.screens.Login
import com.example.finalpro.screens.Profile
import com.example.finalpro.screens.Notifications // Add the correct import for Notifications
import com.example.finalpro.screens.Search
import com.example.finalpro.screens.Register // Ensure the Register screen is imported

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.Splash.route) {
        composable(Routes.Splash.route) {
            Splash(navController)
        }
        composable(Routes.Home.route) {
            Home()
        }
        composable(Routes.Profile.route) {
            Profile()
        }
        composable(Routes.Notifications.route) {
            Notifications()
        }
        composable(Routes.AddThreads.route) {
            AddThreads()
        }
        composable(Routes.Search.route) {
            Search()
        }
        composable(Routes.BottomNav.route) {
            BottomNav(navController)
        }
        composable(Routes.Login.route) {
            Login(navController)
        }
        composable(Routes.Register.route) {
            Register(navController) // Register screen composable
        }
    }
}
