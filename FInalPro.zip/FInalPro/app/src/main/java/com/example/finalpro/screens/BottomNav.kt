package com.example.finalpro.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.NavHostController
import com.example.finalpro.model.BottomNavItem
import com.example.finalpro.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomNav(navController: NavHostController) {
    Scaffold(
        bottomBar = { MyBottomBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(route = Routes.Home.route) {
                Home()
            }
            composable(route = Routes.Profile.route) {
                Profile()
            }
            composable(route = Routes.Notifications.route) {
                Notifications()
            }
            composable(route = Routes.AddThreads.route) {
                AddThreads()
            }
            composable(route = Routes.Search.route) {
                Search()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()

    val list = listOf(
        BottomNavItem(
            title = "Home",
            route = Routes.Home.route,
            icon = Icons.Rounded.Home
        ),
        BottomNavItem(
            title = "Search",
            route = Routes.Search.route,
            icon = Icons.Rounded.Search
        ),
        BottomNavItem(
            title = "Add Threads",
            route = Routes.AddThreads.route,
            icon = Icons.Rounded.Add
        ),
        BottomNavItem(
            title = "Notifications",
            route = Routes.Notifications.route,
            icon = Icons.Rounded.Notifications
        ),
        BottomNavItem(
            title = "Profile",
            route = Routes.Profile.route,
            icon = Icons.Rounded.Person
        ),
    )

    NavigationBar {
        list.forEach { item ->
            val selected = item.route == backStackEntry?.destination?.route

            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    Icon(imageVector = item.icon, contentDescription = item.title)
                },
                label = {
                    Text(item.title)
                }
            )
        }
    }
}
